/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

#ifndef COMMONLOG_MACHINE_H
#define COMMONLOG_MACHINE_H

@TOP@
@BOTTOM@

#endif /* COMMONLOG_MACHINE_H */
