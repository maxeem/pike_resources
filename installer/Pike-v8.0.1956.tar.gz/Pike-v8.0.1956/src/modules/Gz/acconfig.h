/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

#ifndef GMP_MACHINE_H
#define GMP_MACHINE_H

@TOP@
@BOTTOM@

/* Define this if you have -lz */
#undef HAVE_LIBZ

#endif
