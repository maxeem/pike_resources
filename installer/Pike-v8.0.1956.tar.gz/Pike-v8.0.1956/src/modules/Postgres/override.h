/* These are defined inside the Postgres library headers as well.
 * We don't want the redefine-warnings.
 */

#undef PACKAGE_BUGREPORT
#undef PACKAGE_NAME
#undef PACKAGE_STRING
#undef PACKAGE_TARNAME
#undef PACKAGE_VERSION
