/* Define to 1 if you have the `FindFirstChangeNotification' function. */
#undef HAVE_FINDFIRSTCHANGENOTIFICATION
