void init_linkfarm_program(void);
void exit_linkfarm_program(void);
