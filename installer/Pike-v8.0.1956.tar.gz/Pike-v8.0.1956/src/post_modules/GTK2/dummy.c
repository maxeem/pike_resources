/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

#include "global.h"
#include "pgtk_config.h"
#include "module.h"

/* Well... Sort of basic, right? :-) */

PIKE_MODULE_INIT
{
}

PIKE_MODULE_EXIT
{
}
