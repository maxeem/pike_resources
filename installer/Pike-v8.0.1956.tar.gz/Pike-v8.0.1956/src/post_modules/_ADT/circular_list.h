
void pike_init_CircularList_module(void);
void pike_exit_CircularList_module(void);

