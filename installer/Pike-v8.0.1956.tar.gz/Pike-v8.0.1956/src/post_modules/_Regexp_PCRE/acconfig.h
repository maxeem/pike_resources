/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

@TOP@

/* Define this if you have -lpcre */
#undef HAVE_LIBPCRE

@BOTTOM@
